import sys

from mydata import PersonService
from mydata import ttypes
from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TCompactProtocol

'''
Thrift Demo:Python Client
'''
try:
    print(sys.version_info)

    # 创建一个传输层对象
    tSocket = TSocket.TSocket('localhost', 8888)
    tSocket.setTimeout(600)
    transport = TTransport.TFramedTransport(tSocket)
    # 创建一个通信协议对象
    protocol = TCompactProtocol.TCompactProtocol(transport)
    # 创建一个Thrift客户端对象
    client = PersonService.Client(protocol)

    print("Thrift DEMO: Connect Python Server...")
    # 建立与Java Server间的socket连接
    transport.open()
    print("Thrift DEMO: Python Client 远端调用 Java Server 方法接口: " + "getPersonByUsername(String username)")

    person = client.getPersonByUsername("Python Client")

    print("Thrift DEMO: Python Client 远端调用 Java Server 返回结果：")

    print("-" * 10)
    print(person.username)
    print(person.age)
    print(person.married)
    print("-" * 10)

    print("Thrift DEMO: Python Client 一次调用结束！")

    transport.close()

except Thrift.TException as tx:
    print(tx.message)
finally:
    pass