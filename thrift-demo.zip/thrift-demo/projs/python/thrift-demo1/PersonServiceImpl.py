from mydata import ttypes

'''
Thrift Demo: Python Server PersonServiceImpl
'''
class PersonServiceImpl:
    def getPersonByUsername(self, username):
        print('Python 服务端获取到客户端传来的参数:' + username)

        person = ttypes.Person()
        person.username = "Python Server"
        person.age = 18
        person.married = False
        return person