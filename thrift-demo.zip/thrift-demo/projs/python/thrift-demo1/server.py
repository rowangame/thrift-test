from mydata import PersonService
from PersonServiceImpl import PersonServiceImpl
from thrift import Thrift
from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TCompactProtocol
from thrift.server import TServer

'''
Thrift Demo:Python Server
'''
try:
    # 初始化socket
    serverSocket = TSocket.TServerSocket(host='127.0.0.1', port=8888)
    personServiceHandler = PersonServiceImpl()
    processor = PersonService.Processor(personServiceHandler)
    # Thrift协议层设置 选择二进制协议
    transportFactory = TTransport.TFramedTransportFactory()
    # Thrift传输层设置 选择帧模式
    protocolFactory = TCompactProtocol.TCompactProtocolFactory()

    server = TServer.TSimpleServer(processor, serverSocket, transportFactory, protocolFactory)
    print("Thrift Demo: Python Server Start...")
    server.serve()

except Thrift.TException as ex:
    print(ex.message)
finally:
    pass
