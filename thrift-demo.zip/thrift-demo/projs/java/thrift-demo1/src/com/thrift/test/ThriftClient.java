package com.thrift.test;

import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.layered.TFramedTransport;

import thrift.generated.Person;
import thrift.generated.PersonService;

/**
 * Thrift Demo:Java Client
 */
public class ThriftClient {
    public static void main(String[] args)  {
    	TTransport transport = null;
    	try {
            //创建一个传输层对象
            transport = new TFramedTransport(new TSocket("localhost", 8888), 600);
            //创建一个通信协议对象
            TProtocol protocol = new TCompactProtocol(transport);
            //创建一个thrift客户端对象
            PersonService.Client client = new PersonService.Client(protocol);
            
            System.out.println("Thrift DEMO: Connect Python Server...");
            //建立与Python Server间的socket连接
            transport.open();

            System.out.println("Thrift DEMO: Java Client 远端调用 Python Server 方法接口: " + "getPersonByUsername(String username)");

            //通过客户端对象远端调用服务器服务函数getPersonByUsername
            System.out.println("Thrift DEMO: Java Client 向 Python Server 传递输入参数 username: " + "JAVA Client");
            Person person = client.getPersonByUsername("JAVA Client");

            System.out.println("Thrift DEMO: Java Client 远端调用 Python Server 返回结果：");
            //output result
            System.out.println("---------------------------");
            System.out.println("username:" + person.getUsername());
            System.out.println("age: " + person.getAge());
            System.out.println("married: " + person.isMarried());
            System.out.println("---------------------------");

            System.out.println("Thrift DEMO: Java Client 一次调用结束！");

        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            transport.close();
        }
    }
}