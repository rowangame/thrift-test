package com.thrift.test;

import org.apache.thrift.TException;

import thrift.generated.DataException;
import thrift.generated.Person;
import thrift.generated.PersonService;

/**
 * Thrift Demo: Java Server PersonServiceImpl
 */
public class PersonServiceImpl implements PersonService.Iface {

    @Override
    public Person getPersonByUsername(String username) throws DataException, TException {
        
        System.out.println("getPersonByUsername被调用并收到参数:" + username);
        Person person = new Person();
        person.setUsername("JAVA Server");
        person.setAge(10);
        person.setMarried(false);

        return person;
    }

	@Override
	public void savePerson(Person person) throws DataException, TException {
		System.out.println(String.format("savePerson->%d,%s", person.age, person.married));
	}

}