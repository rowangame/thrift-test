package com.thrift.test;

import org.apache.thrift.TProcessorFactory;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.server.THsHaServer;
import org.apache.thrift.server.TServer;
import org.apache.thrift.transport.layered.TFramedTransport;

import thrift.generated.PersonService;

import org.apache.thrift.transport.TNonblockingServerSocket;

/**
 * Thrift Demo:Java Server
 */
public class ThriftServer {
    public static void main(String[] args) throws Exception
    {
        //初始化socket
        TNonblockingServerSocket serverSocket  = new TNonblockingServerSocket(8888);
        //初始化服务核心类
        THsHaServer.Args arg = new THsHaServer.Args(serverSocket).minWorkerThreads(2).maxWorkerThreads(4);
        //初始化服务核心类
        PersonService.Processor<PersonServiceImpl> processor = new PersonService.Processor<>(new PersonServiceImpl());
        //配置服务核心类，Thrift协议层设置 选择二进制协议
        arg.protocolFactory(new TCompactProtocol.Factory());
        //配置服务核心类，Thrift传输层设置 选择帧模式
        arg.transportFactory(new TFramedTransport.Factory());
        //配置服务核心类
        arg.processorFactory(new TProcessorFactory(processor));
        //完成服务核心类的初始化和配置
        TServer server = new THsHaServer(arg);
        
        System.out.println("Thrift Java Server Start...");
        //服务启动
        server.serve();
    }
}