package com.log.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

@SuppressWarnings("unused")
public class LogTest {
	private static org.slf4j.Logger _LOGGER = org.slf4j.LoggerFactory.getLogger(LogTest.class.getName());;

	/**
	 * log4j:WARN No appenders could be found for logger (com.log.test.LogTest).
	 * log4j:WARN Please initialize the log4j system properly. log4j:WARN See
	 * http://logging.apache.org/log4j/1.2/faq.html#noconfig for more info.
	 * 手动初始化,解决当前问题
	 */
	public static void initLog() {
		/**
		FileInputStream fileInputStream = null;
		try {
			Properties properties = new Properties();
			fileInputStream = new FileInputStream("src/config/resources/log4j.properties");
			properties.load(fileInputStream);
			PropertyConfigurator.configure(properties);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} **/
		// 或者指定目录文件
		PropertyConfigurator.configure("src/config/resources/log4j.properties");
	}

	public static void test1() {
		System.out.println("test1...process");
	}

	public static void test2() {
		System.out.println("test2...process");
	}

	public static void test3() {
		System.out.println("test3...process");
	}

	public static void main(String args[]) {
		 // 如下方法指定文件
		 initLog();

		_LOGGER.info("Current Time: {}", System.currentTimeMillis());
		_LOGGER.info("Current Time: " + System.currentTimeMillis());
		_LOGGER.info("Current Time: {}", System.currentTimeMillis());
		_LOGGER.trace("trace log");
		_LOGGER.warn("warn log");
		_LOGGER.debug("debug log");
		_LOGGER.info("info log");
		
		_LOGGER.error("error log");
	}
}
